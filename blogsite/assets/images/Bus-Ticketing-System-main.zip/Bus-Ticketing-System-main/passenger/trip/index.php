<link rel="stylesheet" href="../../assets/css/style.css">

<title>Bus Teckiting System</title>
<br>
<div class="container-fluid">
      <?php include ('includes/navbar.php'); ?>
      <br><br>
  <main role="main">
      <h1>Available Trip</h1>
        <div class="jumbotron">
            <div class="card">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                    <tr>
                        <th>Bus Number</th>
                        <th>Departure</th>
                        <th>Arrival</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Driver</th>
                        <th>Conductor</th>
                        <th>Base Fair</th>
                        <th>Discount Fair</th> 
                        <th>Status</th>
                        <th>Note</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr></tr>
                    </tbody>
                </table>       
            </div>
        </div>
  </main>
</div>
<script src="../../assets/js/jquery.js"></script>
<script src="../../assets/js/script.js"></script>