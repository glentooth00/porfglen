<?php 

use App\Models\Employee;

require_once realpath('../../vendor/autoload.php');

if($_GET['employee_id']){

    (new Employee)->delete('employee_id',$_GET['employee_id']);
    header("Location: ".$_SERVER['HTTP_REFERER']);

}