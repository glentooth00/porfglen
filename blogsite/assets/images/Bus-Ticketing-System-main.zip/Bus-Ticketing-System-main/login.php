<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title> 
         <!--Bootstrap core CSS  -->
        <link rel="stylesheet" href="assets/css/style.css">
</head>
<body style="background-image: url(assets/img/blue-gradient-background.jpg); background-repeat:no-repeat; background-size: cover;">
    <div id="layoutAuthentication">
         <div id="layoutAuthentication_content">
             <main><br>
                  <div class="container">
                    <h2 style="text-align: center;"><br> Bus Teckiting System</h2><br><br>
                        <div class="row justify-content-center">
                            <div class="col-lg-4">                                    
                                <div class="card-header bg-light"><h2 class="my-1 text-dark" style="text-align: center;">ADMIN</h2></div>
                                    <div class="card-body bg-light">
                                            <form method="POST" action="process-login.php">  
                                                     <?php include('includes/session/session.php'); ?>                                                  
                                                    <div class="form-group">
                                                            <label class="small" for="inputEmailAddress">Email</label>
                                                            <input class="form-control" name="username" type="email" placeholder="Enter username" required />
                                                    </div>
                                                    <div class="form-group">
                                                            <label class="small" for="inputPassword">Password</label>
                                                            <input class="form-control " name="password" type="password" 
                                                            placeholder="Enter password" required/>
                                                    </div>
                                                    <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                                                            <button type="submit" class="btn btn-primary btn-sm col-md-12" style="padding: 3%;"> <i class="align-middle mr-2" data-feather="log-in"></i>Login</button>
                                                        </div>
                                                        <br>
                                                        <a href="index.php" style="margin-left:33%;">back to portal</a>
                                            </form>
                                    </div>       
                            </div>
                        </div>
                   </div>
             </main>
         </div>
     </div>
</body>
</html>