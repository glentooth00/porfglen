<?php 
namespace App\DB;

use PDO;

class Database{

    public $dsn = 'mysql:host=localhost;dbname=thesis_bus_reservation;charset=utf8mb4';
    public $username = 'root';
    public $password = '';
    public $charset = 'utf8mb4';
    public $pdo;


    function __construct(){
        
        $this->pdo = new PDO($this->dsn,$this->username,$this->password);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::ATTR_ERRMODE);
        return $this->pdo;
    }


}