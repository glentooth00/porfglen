<?php 
namespace App\DB;


class BaseModel{

    public $sql;
    public $db;
    private $conn;
    private $query;


    function __construct(){
        $this->conn = new Database;
    }

    function select($items){
        $this->sql = "SELECT $items FROM " . $this->table;
        return $this;
    }

    function find($id){
        $this->select('*')->where('id', $id);
        $result =  $this->query()->query->fetch_assoc();
        if($result){
            return $result;
        }else{
            return null;
        }
    }

    function all(){
        $this->select('*')->query($this->sql);
        return $this->query;
    }

    function get(){
        $this->query($this->sql);
        return $this->query;
    }



    //INSERT INTO users (name, surname, sex) VALUES (?,?,?
    function insert($values){
        $sql = "INSERT INTO " . $this->table  . " (";
        $counter1 = 1;
        $counter2 = 1;
        foreach($values as $index => $value ){
            $sql .= "`". $index . "`";
            $counter1++;
                if(count($values) >= $counter1){
                    $sql .=  ', ';
            }
        }
        $sql .= ") VALUES (";

        foreach($values as $index => $value ){
            $sql .= "'" . $value . "'";
            $counter2++;
            if(count($values) >= $counter2){
                    $sql .=  ', ';
            }
        }
        $sql .= ")";

        $this->sql = $sql;
        return $this;
    }

    function update($values){
        $counter1 = 1;
        $sql = "UPDATE " . $this->table  . " SET ";
        foreach($values as $index => $value ){
                $sql .=  $index .  '="' . $value . '" ';
                $counter1++;
                if(count($values) >= $counter1){
                        $sql .=  ', ';
                }
        }

        $sql .= ' ';

        $this->sql = $sql;
        return $this; 
    }



    function save($table = null){
        if($table){
            $this->table = $table;
        }

        $this->query();
    }


    function where($column, $value){
        $this->sql .= " WHERE $column=$value ";
        return $this;
    }

    function orderBy($column, $sorting){
        $this->sql .= " ORDER BY $column $sorting ";
        return $this;
    }

    function whereAnd($column, $value){
        $this->sql .= "AND WHERE $column=$value ";
        return $this;
    }

    
    function whereLike($column, $value){
        $this->sql .= " WHERE $column LIKE '$value' ";
        return $this;
    }

    function andWhereLike($column, $value){
        $this->sql .= "AND WHERE $column LIKE $value ";
        return $this;
    }

    function delete($column, $value){
        $this->sql .= "DELETE FROM $this->table WHERE $column = $value";
        return $this->query();
    }


    function query(){
        $this->query = mysqli_query($this->conn, $this->sql);
        if(!$this->query){
            echo mysqli_error();
        }
        return $this;
    }
}
