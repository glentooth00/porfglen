<?php
namespace App\Models;

use App\DB\BaseModel;

class Employee extends BaseModel{
    protected $table = 'employees';

}