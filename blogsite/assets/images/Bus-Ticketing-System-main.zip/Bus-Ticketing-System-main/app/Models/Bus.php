<?php
namespace App\Models;

use App\DB\BaseModel;

class Bus extends BaseModel{
    protected $table = 'buses';

}