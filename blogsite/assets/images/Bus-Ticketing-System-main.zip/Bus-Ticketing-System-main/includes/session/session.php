<?php if(isset($_SESSION['login-error'])):?>
    <center>
        <div class="alert alert-danger">
             <?= $_SESSION['login-error'] ?>
             <?php unset($_SESSION['login-error']); ?>
        </div> 
     </center>
<?php endif; ?>  