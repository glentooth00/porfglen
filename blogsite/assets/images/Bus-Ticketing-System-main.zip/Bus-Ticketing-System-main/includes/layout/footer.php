

<script src="../assets/js/script.js"></script>
<script src="../assets/js/icons.js"></script>
<script src="../assets/js/jquery.js"></script>
</body>
</html>