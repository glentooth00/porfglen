<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse" style="background-color: rgb(14, 28, 66);">
      <div class="sidebar-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link" href="../dashboard/">
              <span data-feather="home"></span>
              Dashboard 
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../user/">
              <span data-feather="users"></span>
              User
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../employee">
              <span data-feather="briefcase"></span>
             Employee
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../bus/">
              <span data-feather="users"></span>
              Bus
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../trip/">
              <span data-feather="map-pin"></span>
              Trip
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="list"></span>
              Passenger
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="list"></span>
              Booking
            </a>
         </li>
         <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="settings"></span>
              Settings
            </a>
         </li>
        </ul>
      </div>
    </nav>