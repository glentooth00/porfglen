<?php
include('../../includes/layout/header.php'); 
include('../../includes/layout/nav.php'); 
include('../../includes/layout/sidenav.php'); 
?>

<link href="../../assets/css/style.css" rel="stylesheet">

<link href="../../assets/css/dashboard.css" rel="stylesheet">

    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Bus</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
              </div>
            
            </div>
          </div>    
          <a href="create.php" class="btn btn-primary btn-sm mb-2"><span data-feather="plus"></span> Add new bus</a>     
              
          <table class="table table-bordered table-hover table-striped">
            <thead>
              <tr>
                <th>Bus Number</th>
                <th>Bus Name</th>
                <th>Capacity</th>
                <th>Baggage Load</th>
                <th>Bus Type</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              
            <tr></tr>

            </tbody>
          </table>
        </main>
      </div>
    </div>

<script src="../../assets/js/script.js"></script>
<script src="../../assets/js/icons.js"></script>
<script src="../../assets/js/jquery.js"></script>
</body>
</html>
