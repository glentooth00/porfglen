<?php 
use App\Models\Bus;

require_once realpath('../../vendor/autoload.php');

if($_GET['bus_id']){

    (new Bus)->delete('bus_id',$_GET['bus_id']);
    header("Location: ".$_SERVER['HTTP_REFERER']);

}