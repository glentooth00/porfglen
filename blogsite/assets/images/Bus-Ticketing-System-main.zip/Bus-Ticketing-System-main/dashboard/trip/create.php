<?php
include('../../includes/layout/header.php'); 
include('../../includes/layout/nav.php'); 
include('../../includes/layout/sidenav.php'); 
?>
<link href="../../assets/css/style.css" rel="stylesheet">

<link href="../../assets/css/dashboard.css" rel="stylesheet">

 <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Add new Trip</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
          </div>
        </div>
      </div>    
      <div class="card mb-3 col-md-9">
        <div class="card-body col-md-12">
            <form action="" method="" enctype="multipart/form"> 
                <div class="form-row">
                <div class="col-md-4">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Bus Number</label>
                             <select class="form-control" name="bus_id" required>
                                 <option value="">----- Select ------</option>
                             </select>
                        </div>
                   </div>
                   <div class="col-md-4">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Departure Date/Time</label>
                             <div class="nativeDateTimePicker">
                                <input type="datetime-local" id="party" name="departure" class="form-control" required>
                                <span class="validity"></span>
                            </div>
                        </div>
                   </div>
                   <div class="col-md-4">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Arrival Date/Time</label>
                             <div class="nativeDateTimePicker">
                                <input type="datetime-local" id="party" name="arrival" class="form-control" required>
                                <span class="validity"></span>
                            </div>
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">From</label><input class="form-control" type="text" name="from" required />
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">To</label><input class="form-control" type="text" name="to" required />
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Driver</label>
                             <select class="form-control" required>
                                 <option value="">----- select -----</option>
                             </select>
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Conductor</label>
                             <select class="form-control" required>
                                 <option value="">----- select -----</option>
                             </select>
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Base Fair</label><input class="form-control" type="text" name="base_fair" required />
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Discount Fair</label><input class="form-control" type="text" name="discount_fair" required />
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Status</label>
                             <select class="form-control" required>
                                 <option value="">----- select -----</option>
                             </select>
                        </div>
                   </div>
                   <div class="col-md-6">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Note</label>
                             <textarea name="" id="input" class="form-control" rows="3" placeholder="Optional.." ></textarea>
                             
                        </div>
                   </div>
                </div>
                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                <a href="index.php" class="btn btn-secondary">Cancel</a>
            </form>
         </div>
      </div>
    </main>
  </div>
</div>


<script src="../../assets/js/script.js"></script>
<script src="../../assets/js/icons.js"></script>
<script src="../../assets/js/jquery.js"></script>
</body>
</html>
