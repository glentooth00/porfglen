
<?php
include('../../includes/layout/header.php'); 
include('../../includes/layout/nav.php'); 
include('../../includes/layout/sidenav.php'); 
?>
<link href="../../assets/css/style.css" rel="stylesheet">

<link href="../../assets/css/dashboard.css" rel="stylesheet">

 <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Add new Employee</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
          </div>
        </div>
      </div>    
      <div class="card mb-3 col-md-7">
        <div class="card-body col-md-12">
            <form action="store.php" method="post" enctype="multipart/form"> 
                <div class="form-row">
                    <div class="col-md-12">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Name</label><input class="form-control" type="text" placeholder="Enter name" name="name" required />
                        </div>
                   </div>
                   <div class="col-md-12">
                        <div class="form-group">
                             <label class="mb-1" for="inputFirstName">Employee Type</label>
                             <select name="type" class="form-control">
                                 <option value="driver">Driver</option>
                                 <option value="conductor">Conductor</option>
                             </select>
                        </div>
                   </div>
                </div>
                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                <a href="index.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
      </div>
    </main>
  </div>
</div>


<script src="../../assets/js/script.js"></script>
<script src="../../assets/js/icons.js"></script>
<script src="../../assets/js/jquery.js"></script>
</body>
</html>
