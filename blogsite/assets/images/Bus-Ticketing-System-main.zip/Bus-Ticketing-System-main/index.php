
<?php

use App\Models\Employee;

require_once realpath('../../vendor/autoload.php');
include('../../includes/layout/header.php'); 
include('../../includes/layout/nav.php'); 
include('../../includes/layout/sidenav.php'); 
?>


<link href="../../assets/css/style.css" rel="stylesheet">
<link href="../../assets/bootstraptable/dataTables.bootstrap4.min.css" rel="stylesheet">
<link href="../../assets/css/dashboard.css" rel="stylesheet">


 <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Employee</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
           
          </div>
        
        </div>
      </div>
      <a href="create.php" class="btn btn-primary btn-sm mb-2"><span data-feather="plus"></span> Add new employee</a>     
      <div class="card mb-4">
          <div class="card-body">
               <div class="table-responsive">
                    <?php
                      $employee = (new Employee)->select('*')->get();
                    ?>
                  <table class="table table-bordered table-hover table-striped">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                  <?php foreach($employee as $employ): ?>
                    <tbody>
                    <tr>

                      <td><?= $employ['name'] ?></td>
                      <td><?= $employ['type'] ?></td>
                      <td>
                          <a href="edit.php" class="btn btn-success btn-sm"> <i class="fas fa-pen"></i> Edit</a>
                          <a href="delete.php?employee_id=<?=  $employ['employee_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this entry?')"><i class="fas fa-trash"></i> Delete</a>
                        </td>


                    </tr>
                    </tbody>
                  <?php endforeach; ?>
                  </table>
               </div>
           </div>
       </div>
    </main>
  </div>
</div>

<script src="../../assets/js/script.js"></script>
<script src="../../assets/js/icons.js"></script>
<script  src="../../assets/bootstraptable/bootstrap.min.js"></script>
<script  src="../../assets/bootstraptable/jquery.dataTables.min.js"></script>
<script  src="../../assets/bootstraptable/dataTables.bootstrap4.min.js"></script>
<script src="../../assets/js/dataTable.js"></script>