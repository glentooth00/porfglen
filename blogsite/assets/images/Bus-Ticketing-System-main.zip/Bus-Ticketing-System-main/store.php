<?php

use App\Models\Employee;

require_once realpath('../../vendor/autoload.php');

if($_POST){

    (new Employee)->addemployee([
        'name' => $_POST['name'],
        'type' => $_POST['type']
    ]);

}
